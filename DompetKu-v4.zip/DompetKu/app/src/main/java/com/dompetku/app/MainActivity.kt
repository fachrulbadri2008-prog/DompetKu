package com.dompetku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val amount: Long,
    val category: String,
    val note: String,
    val date: String,
    val savingId: String? = null
)

data class SavingGoal(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val target: Long,
    val saved: Long = 0L,
    val targetDate: String = "",
    val note: String = ""
)

class FinanceViewModel : ViewModel() {
    var transactions by mutableStateOf(emptyList<Transaction>())
        private set

    var savingsGoals by mutableStateOf(emptyList<SavingGoal>())
        private set

    val income: Long get() = transactions.filter { it.type == "income" }.sumOf { it.amount }
    val expense: Long get() = transactions.filter { it.type == "expense" }.sumOf { it.amount }
    val savedTotal: Long get() = savingsGoals.sumOf { it.saved }
    val balance: Long get() = income - expense - savedTotal

    fun add(type: String, amount: Long, category: String, note: String, savingId: String? = null) {
        if (amount <= 0) return
        if (type == "saving" && savingId != null) {
            val goal = savingsGoals.find { it.id == savingId } ?: return
            savingsGoals = savingsGoals.map {
                if (it.id == savingId) it.copy(saved = it.saved + amount) else it
            }
        }
        transactions = listOf(
            Transaction(type=type, amount=amount, category=category, note=note, date="Hari ini", savingId=savingId)
        ) + transactions
    }

    fun createSaving(name: String, target: Long, targetDate: String, note: String) {
        if (name.isBlank() || target <= 0) return
        savingsGoals = savingsGoals + SavingGoal(name=name, target=target, targetDate=targetDate, note=note)
    }

    fun addToSaving(goal: SavingGoal, amount: Long, note: String) =
        add("saving", amount, goal.name, note, goal.id)

    fun removeFromSaving(goal: SavingGoal, amount: Long, note: String) {
        if (amount <= 0) return
        val actual = amount.coerceAtMost(goal.saved)
        savingsGoals = savingsGoals.map {
            if (it.id == goal.id) it.copy(saved = it.saved - actual) else it
        }
        transactions = listOf(
            Transaction(type="saving_remove", amount=actual, category=goal.name, note=note, date="Hari ini", savingId=goal.id)
        ) + transactions
    }

    fun deleteTransaction(t: Transaction) {
        if (t.type == "saving" && t.savingId != null) {
            savingsGoals = savingsGoals.map {
                if (it.id == t.savingId) it.copy(saved = (it.saved - t.amount).coerceAtLeast(0)) else it
            }
        } else if (t.type == "saving_remove" && t.savingId != null) {
            savingsGoals = savingsGoals.map {
                if (it.id == t.savingId) it.copy(saved = (it.saved + t.amount)) else it
            }
        }
        transactions = transactions.filterNot { it.id == t.id }
    }

    fun deleteSaving(goal: SavingGoal) {
        transactions = transactions.filterNot { it.savingId == goal.id }
        savingsGoals = savingsGoals.filterNot { it.id == goal.id }
    }
}

fun rupiah(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id","ID")).apply {
        maximumFractionDigits = 0
        minimumFractionDigits = 0
    }.format(value)

private val Bg = Color(0xFF0B0D12)
private val Card = Color(0xFF151922)
private val Accent = Color(0xFF8B7CFF)
private val Green = Color(0xFF4ADE80)
private val Red = Color(0xFFFF6B7A)
private val Text = Color(0xFFF4F5F7)
private val Muted = Color(0xFF9AA1AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DompetKuApp() }
    }
}

@Composable
fun DompetKuApp(vm: FinanceViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Accent,
            onBackground = Text, onSurface = Text
        )
    ) {
        Scaffold(
            containerColor = Bg,
            floatingActionButton = {
                if (tab == 0 || tab == 1) {
                    FloatingActionButton(onClick = { showAdd = true }, containerColor = Accent) {
                        Icon(Icons.Default.Add, "Tambah")
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Card) {
                    listOf(
                        Icons.Default.Home to "Beranda",
                        Icons.Default.ReceiptLong to "Transaksi",
                        Icons.Default.Savings to "Tabungan",
                        Icons.Default.BarChart to "Statistik"
                    ).forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(item.first, null) },
                            label = { Text(item.second) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab) {
                    0 -> HomeScreen(vm)
                    1 -> TransactionScreen(vm)
                    2 -> SavingsScreen(vm)
                    else -> StatisticsScreen(vm)
                }
            }
        }
        if (showAdd) AddTransactionDialog(
            onDismiss = { showAdd = false },
            onSave = { type, amount, category, note ->
                vm.add(type, amount, category, note)
                showAdd = false
            }
        )
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(20.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Muted, modifier = Modifier.padding(top=4.dp))
    }
}

@Composable
fun HomeScreen(vm: FinanceViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom=90.dp)) {
        item {
            Header("DompetKu", "Keuangan pribadi kamu")
            Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(), shape=RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Saldo tersedia", color=Muted)
                    Text(rupiah(vm.balance), fontSize=32.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=6.dp))
                    Row(Modifier.fillMaxWidth().padding(top=22.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Summary("Pemasukan", vm.income, Green, Modifier.weight(1f))
                        Summary("Pengeluaran", vm.expense, Red, Modifier.weight(1f))
                    }
                }
            }
        }
        item { Text("Transaksi terbaru", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(20.dp,24.dp,20.dp,10.dp)) }
        items(vm.transactions.take(6)) { TransactionRow(it) { vm.deleteTransaction(it) } }
    }
}

@Composable
fun Summary(label: String, value: Long, color: Color, modifier: Modifier) {
    Column(modifier.background(Bg, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(label, color=Muted, fontSize=12.sp)
        Text(rupiah(value), color=color, fontWeight=FontWeight.Bold, fontSize=15.sp, modifier=Modifier.padding(top=5.dp))
    }
}

@Composable
fun TransactionScreen(vm: FinanceViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(bottom=90.dp)) {
        item { Header("Transaksi", "Semua pemasukan dan pengeluaran") }
        items(vm.transactions) { TransactionRow(it) { vm.deleteTransaction(it) } }
    }
}

@Composable
fun TransactionRow(t: Transaction, onDelete: () -> Unit) {
    val isIncome = t.type == "income"
    val isSavingRemove = t.type == "saving_remove"
    val rowColor = when { isIncome -> Green; isSavingRemove -> Red; else -> Red }
    val isSaving = t.type == "saving"
    val rowColor = when { isIncome -> Green; isSaving -> Accent; else -> Red }
    val icon = when { isIncome -> Icons.Default.ArrowDownward; isSaving -> Icons.Default.Savings; else -> Icons.Default.ArrowUpward }
    val prefix = if (isIncome) "+" else "-"
    Row(
        Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=5.dp)
            .background(Card, RoundedCornerShape(16.dp)).padding(15.dp),
        verticalAlignment=Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(rowColor.copy(.15f)), contentAlignment=Alignment.Center) {
            Icon(icon, null, tint=rowColor)
        }
        Column(Modifier.weight(1f).padding(start=12.dp)) {
            Text(if (t.type == "saving") "Tabungan • ${t.category}" else if (isSavingRemove) "Ambil dari • ${t.category}" else t.category, fontWeight=FontWeight.SemiBold)
            Text(if(t.note.isBlank()) t.date else "${t.note} • ${t.date}", color=Muted, fontSize=12.sp)
        }
        Column(horizontalAlignment=Alignment.End) {
            Text(prefix + " " + rupiah(t.amount), color=rowColor, fontWeight=FontWeight.Bold, fontSize=13.sp)
            IconButton(onClick=onDelete, modifier=Modifier.size(30.dp)) { Icon(Icons.Default.DeleteOutline, "Hapus", tint=Muted) }
        }
    }
}

@Composable
fun SavingsScreen(vm: FinanceViewModel) {
    var showCreate by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<SavingGoal?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment=Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Tabungan", fontSize=28.sp, fontWeight=FontWeight.Bold)
                Text("Buat dan kelola banyak target", color=Muted, modifier=Modifier.padding(top=4.dp))
            }
            FilledTonalButton(onClick={ showCreate=true }) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(4.dp))
                Text("Tambah")
            }
        }

        LazyColumn(contentPadding=PaddingValues(16.dp, 0.dp, 16.dp, 100.dp)) {
            if (vm.savingsGoals.isEmpty()) {
                item {
                    Card(shape=RoundedCornerShape(22.dp), modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Savings, null, tint=Accent, modifier=Modifier.size(48.dp))
                            Text("Belum ada tabungan", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=10.dp))
                            Text("Tambahkan target pertama kamu.", color=Muted, modifier=Modifier.padding(top=4.dp))
                            Button(onClick={showCreate=true}, modifier=Modifier.padding(top=16.dp)) {
                                Text("Buat Tabungan")
                            }
                        }
                    }
                }
            }

            items(vm.savingsGoals) { goal ->
                val progress=(goal.saved.toFloat()/goal.target).coerceIn(0f,1f)
                Card(
                    modifier=Modifier.fillMaxWidth().padding(bottom=10.dp),
                    shape=RoundedCornerShape(20.dp),
                    onClick={selected=goal}
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Default.Savings, null, tint=Accent, modifier=Modifier.size(30.dp))
                            Column(Modifier.weight(1f).padding(start=12.dp)) {
                                Text(goal.name, fontSize=18.sp, fontWeight=FontWeight.Bold)
                                Text("${rupiah(goal.saved)} / ${rupiah(goal.target)}", color=Muted, fontSize=13.sp)
                            }
                            Text("${(progress*100).toInt()}%", color=Accent, fontWeight=FontWeight.Bold)
                        }
                        Spacer(Modifier.height(14.dp))
                        LinearProgressIndicator(progress={progress}, modifier=Modifier.fillMaxWidth().height(9.dp))
                        if (progress >= 1f) {
                            Text("Target tercapai 🎉", color=Green, fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=8.dp))
                        } else if (goal.targetDate.isNotBlank()) {
                            Text("Target: ${goal.targetDate}", color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=8.dp))
                        }
                    }
                }
            }
        }
    }

    if (showCreate) {
        CreateSavingDialog(
            onDismiss={showCreate=false},
            onSave={name,target,date,note -> vm.createSaving(name,target,date,note); showCreate=false}
        )
    }

    selected?.let { goal ->
        SavingDetailDialog(
            goal=goal,
            onDismiss={selected=null},
            onAdd={amount,note -> vm.addToSaving(goal,amount,note); selected=null},
            onRemove={amount,note -> vm.removeFromSaving(goal,amount,note); selected=null},
            onDelete={vm.deleteSaving(goal); selected=null}
        )
    }
}

@Composable
fun CreateSavingDialog(
    onDismiss: () -> Unit,
    onSave: (String,Long,String,String)->Unit
) {
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Tambah Tabungan")},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name,{name=it},label={Text("Nama tabungan")},placeholder={Text("Contoh: Beli HP")},singleLine=true)
                OutlinedTextField(target,{target=it.filter(Char::isDigit)},label={Text("Target uang")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
                OutlinedTextField(date,{date=it},label={Text("Target tanggal (opsional)")},singleLine=true)
                OutlinedTextField(note,{note=it},label={Text("Catatan (opsional)")},singleLine=true)
            }
        },
        confirmButton={
            Button(onClick={onSave(name,target.toLongOrNull()?:0,date,note)}){Text("Simpan")}
        },
        dismissButton={TextButton(onClick=onDismiss){Text("Batal")}}
    )
}

@Composable
fun SavingDetailDialog(
    goal: SavingGoal,
    onDismiss: () -> Unit,
    onAdd: (Long,String)->Unit,
    onRemove: (Long,String)->Unit,
    onDelete: ()->Unit
) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("add") }

    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text(goal.name)},
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Text("${rupiah(goal.saved)} dari ${rupiah(goal.target)}", fontWeight=FontWeight.Bold)
                if (goal.targetDate.isNotBlank()) Text("Target: ${goal.targetDate}", color=Muted)
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected=mode=="add",onClick={mode="add"},label={Text("Tambah uang")})
                    FilterChip(selected=mode=="remove",onClick={mode="remove"},label={Text("Kurangi")})
                }
                OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},label={Text("Nominal")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
                OutlinedTextField(note,{note=it},label={Text("Catatan")},singleLine=true)
            }
        },
        confirmButton={
            Button(onClick={
                val n=amount.toLongOrNull()?:0
                if(n>0) if(mode=="add") onAdd(n,note) else onRemove(n,note)
            }){Text("Simpan")}
        },
        dismissButton={
            Row {
                TextButton(onClick=onDelete){Text("Hapus target", color=Red)}
                TextButton(onClick=onDismiss){Text("Tutup")}
            }
        }
    )
}

@Composable
fun StatisticsScreen(vm: FinanceViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header("Statistik", "Ringkasan keuangan")
        Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(), shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Bulan ini", color=Muted)
                Spacer(Modifier.height(16.dp))
                StatLine("Pemasukan", vm.income, Green)
                StatLine("Pengeluaran", vm.expense, Red)
                StatLine("Ditabung", vm.savings, Accent)
            }
        }
        Text("Kategori pengeluaran", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(20.dp,24.dp,20.dp,10.dp))
        vm.transactions.filter{it.type=="expense"}.groupBy{it.category}.forEach { (cat, list) ->
            StatLine(cat, list.sumOf{it.amount}, Text)
        }
    }
}

@Composable
fun StatLine(label: String, value: Long, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical=9.dp), horizontalArrangement=Arrangement.SpaceBetween) {
        Text(label, color=Muted)
        Text(rupiah(value), color=color, fontWeight=FontWeight.Bold)
    }
}

@Composable
fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (String,Long,String,String)->Unit) {
    var type by remember { mutableStateOf("expense") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makanan") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest=onDismiss,
        title={ Text("Tambah transaksi") },
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("income" to "Pemasukan", "expense" to "Pengeluaran", "saving" to "Tabungan").forEach { (v,l) ->
                        FilterChip(selected=type==v, onClick={type=v}, label={Text(l)})
                    }
                }
                OutlinedTextField(amount, { amount=it.filter{c->c.isDigit()} }, label={Text("Nominal")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), singleLine=true)
                OutlinedTextField(category, {category=it}, label={Text("Kategori")}, singleLine=true)
                OutlinedTextField(note, {note=it}, label={Text("Catatan")}, singleLine=true)
            }
        },
        confirmButton={
            Button(onClick={
                val n=amount.toLongOrNull() ?: 0
                if(n>0) onSave(type,n,category,note)
            }) { Text("Simpan") }
        },
        dismissButton={ TextButton(onClick=onDismiss){Text("Batal")} }
    )
}
