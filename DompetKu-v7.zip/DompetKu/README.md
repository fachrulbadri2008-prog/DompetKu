# DompetKu

Personal offline Android finance app with dark mode.

## Features in v1
- Dashboard balance
- Income and expense transactions
- Savings progress
- Basic statistics
- Delete transactions
- Indonesian Rupiah formatting
- Dark mode UI
- Local app state foundation

## Build
Open the project in Android Studio and run:
./gradlew assembleDebug

APK output:
app/build/outputs/apk/debug/app-debug.apk


## v2 build fix
Java and Kotlin JVM targets are both configured for Java 17 to avoid the Gradle/KSP JVM-target mismatch.
