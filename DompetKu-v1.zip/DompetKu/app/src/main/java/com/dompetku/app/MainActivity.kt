package com.dompetku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val amount: Long,
    val category: String,
    val note: String,
    val date: String
)

class FinanceViewModel : ViewModel() {
    var transactions by mutableStateOf(
        listOf(
            Transaction(type="income", amount=2000000, category="Uang saku", note="Uang bulanan", date="Hari ini"),
            Transaction(type="expense", amount=25000, category="Makanan", note="Makan siang", date="Hari ini"),
            Transaction(type="expense", amount=10000, category="Transportasi", note="Ongkos", date="Kemarin")
        )
    )
        private set

    var savings by mutableLongStateOf(500000L)
        private set

    val balance: Long get() = transactions.sumOf { if (it.type == "income") it.amount else -it.amount } - savings
    val income: Long get() = transactions.filter { it.type == "income" }.sumOf { it.amount }
    val expense: Long get() = transactions.filter { it.type == "expense" }.sumOf { it.amount }

    fun add(type: String, amount: Long, category: String, note: String) {
        transactions = listOf(Transaction(type=type, amount=amount, category=category, note=note, date="Hari ini")) + transactions
        if (type == "saving") savings += amount
    }
    fun delete(t: Transaction) { transactions = transactions.filterNot { it.id == t.id } }
}

fun rupiah(value: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id","ID")).apply {
        maximumFractionDigits = 0
        minimumFractionDigits = 0
    }.format(value)

private val Bg = Color(0xFF0B0D12)
private val Card = Color(0xFF151922)
private val Accent = Color(0xFF8B7CFF)
private val Green = Color(0xFF4ADE80)
private val Red = Color(0xFFFF6B7A)
private val Text = Color(0xFFF4F5F7)
private val Muted = Color(0xFF9AA1AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { DompetKuApp() }
    }
}

@Composable
fun DompetKuApp(vm: FinanceViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Accent,
            onBackground = Text, onSurface = Text
        )
    ) {
        Scaffold(
            containerColor = Bg,
            floatingActionButton = {
                if (tab == 0 || tab == 1) {
                    FloatingActionButton(onClick = { showAdd = true }, containerColor = Accent) {
                        Icon(Icons.Default.Add, "Tambah")
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Card) {
                    listOf(
                        Icons.Default.Home to "Beranda",
                        Icons.Default.ReceiptLong to "Transaksi",
                        Icons.Default.Savings to "Tabungan",
                        Icons.Default.BarChart to "Statistik"
                    ).forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(item.first, null) },
                            label = { Text(item.second) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(tab) {
                    0 -> HomeScreen(vm)
                    1 -> TransactionScreen(vm)
                    2 -> SavingsScreen(vm)
                    else -> StatisticsScreen(vm)
                }
            }
        }
        if (showAdd) AddTransactionDialog(
            onDismiss = { showAdd = false },
            onSave = { type, amount, category, note ->
                vm.add(type, amount, category, note)
                showAdd = false
            }
        )
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(20.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Muted, modifier = Modifier.padding(top=4.dp))
    }
}

@Composable
fun HomeScreen(vm: FinanceViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom=90.dp)) {
        item {
            Header("DompetKu", "Keuangan pribadi kamu")
            Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(), shape=RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("Saldo tersedia", color=Muted)
                    Text(rupiah(vm.balance), fontSize=32.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=6.dp))
                    Row(Modifier.fillMaxWidth().padding(top=22.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Summary("Pemasukan", vm.income, Green, Modifier.weight(1f))
                        Summary("Pengeluaran", vm.expense, Red, Modifier.weight(1f))
                    }
                }
            }
        }
        item { Text("Transaksi terbaru", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(20.dp,24.dp,20.dp,10.dp)) }
        items(vm.transactions.take(6)) { TransactionRow(it) { vm.delete(it) } }
    }
}

@Composable
fun Summary(label: String, value: Long, color: Color, modifier: Modifier) {
    Column(modifier.background(Bg, RoundedCornerShape(16.dp)).padding(14.dp)) {
        Text(label, color=Muted, fontSize=12.sp)
        Text(rupiah(value), color=color, fontWeight=FontWeight.Bold, fontSize=15.sp, modifier=Modifier.padding(top=5.dp))
    }
}

@Composable
fun TransactionScreen(vm: FinanceViewModel) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(bottom=90.dp)) {
        item { Header("Transaksi", "Semua pemasukan dan pengeluaran") }
        items(vm.transactions) { TransactionRow(it) { vm.delete(it) } }
    }
}

@Composable
fun TransactionRow(t: Transaction, onDelete: () -> Unit) {
    val isIncome = t.type == "income"
    Row(
        Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=5.dp)
            .background(Card, RoundedCornerShape(16.dp)).padding(15.dp),
        verticalAlignment=Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(if(isIncome) Green.copy(.15f) else Red.copy(.15f)), contentAlignment=Alignment.Center) {
            Icon(if(isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint=if(isIncome) Green else Red)
        }
        Column(Modifier.weight(1f).padding(start=12.dp)) {
            Text(t.category, fontWeight=FontWeight.SemiBold)
            Text(if(t.note.isBlank()) t.date else "${t.note} • ${t.date}", color=Muted, fontSize=12.sp)
        }
        Column(horizontalAlignment=Alignment.End) {
            Text((if(isIncome) "+" else "-") + " " + rupiah(t.amount), color=if(isIncome) Green else Red, fontWeight=FontWeight.Bold, fontSize=13.sp)
            IconButton(onClick=onDelete, modifier=Modifier.size(30.dp)) { Icon(Icons.Default.DeleteOutline, "Hapus", tint=Muted) }
        }
    }
}

@Composable
fun SavingsScreen(vm: FinanceViewModel) {
    val target = 3000000L
    val progress = (vm.savings.toFloat()/target).coerceIn(0f,1f)
    Column(Modifier.fillMaxSize()) {
        Header("Tabungan", "Target dan progres menabung")
        Card(Modifier.padding(16.dp).fillMaxWidth(), shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Savings, null, tint=Accent, modifier=Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Tabungan HP", fontWeight=FontWeight.Bold, fontSize=20.sp)
                        Text("Target ${rupiah(target)}", color=Muted)
                    }
                }
                Spacer(Modifier.height(22.dp))
                LinearProgressIndicator(progress={progress}, modifier=Modifier.fillMaxWidth().height(10.dp), color=Accent)
                Text("${(progress*100).toInt()}% • ${rupiah(vm.savings)} terkumpul", color=Muted, modifier=Modifier.padding(top=10.dp))
            }
        }
    }
}

@Composable
fun StatisticsScreen(vm: FinanceViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header("Statistik", "Ringkasan keuangan")
        Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(), shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("Bulan ini", color=Muted)
                Spacer(Modifier.height(16.dp))
                StatLine("Pemasukan", vm.income, Green)
                StatLine("Pengeluaran", vm.expense, Red)
                StatLine("Ditabung", vm.savings, Accent)
            }
        }
        Text("Kategori pengeluaran", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(20.dp,24.dp,20.dp,10.dp))
        vm.transactions.filter{it.type=="expense"}.groupBy{it.category}.forEach { (cat, list) ->
            StatLine(cat, list.sumOf{it.amount}, Text)
        }
    }
}

@Composable
fun StatLine(label: String, value: Long, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical=9.dp), horizontalArrangement=Arrangement.SpaceBetween) {
        Text(label, color=Muted)
        Text(rupiah(value), color=color, fontWeight=FontWeight.Bold)
    }
}

@Composable
fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (String,Long,String,String)->Unit) {
    var type by remember { mutableStateOf("expense") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makanan") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest=onDismiss,
        title={ Text("Tambah transaksi") },
        text={
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    listOf("income" to "Pemasukan", "expense" to "Pengeluaran", "saving" to "Tabungan").forEach { (v,l) ->
                        FilterChip(selected=type==v, onClick={type=v}, label={Text(l)})
                    }
                }
                OutlinedTextField(amount, { amount=it.filter{c->c.isDigit()} }, label={Text("Nominal")}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number), singleLine=true)
                OutlinedTextField(category, {category=it}, label={Text("Kategori")}, singleLine=true)
                OutlinedTextField(note, {note=it}, label={Text("Catatan")}, singleLine=true)
            }
        },
        confirmButton={
            Button(onClick={
                val n=amount.toLongOrNull() ?: 0
                if(n>0) onSave(type,n,category,note)
            }) { Text("Simpan") }
        },
        dismissButton={ TextButton(onClick=onDismiss){Text("Batal")} }
    )
}
